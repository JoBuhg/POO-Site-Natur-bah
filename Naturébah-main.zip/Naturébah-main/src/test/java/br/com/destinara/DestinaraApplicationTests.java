package br.com.destinara;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DestinaraApplicationTests {

	@Test
	void contextLoads() {
	}

}
