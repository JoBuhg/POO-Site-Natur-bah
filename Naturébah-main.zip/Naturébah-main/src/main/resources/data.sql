CREATE TABLE travel_package (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(50) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    paragraph1 TEXT,
    paragraph2 TEXT
);

CREATE TABLE app_user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    cpf VARCHAR(11) NOT NULL,
    birth_date DATE NOT NULL,
    sex CHAR(1) NOT NULL,
    email VARCHAR(100),
    password VARCHAR(25) NOT NULL
);

CREATE TABLE purchase (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    travel_package_id INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES app_user(id),
    FOREIGN KEY (travel_package_id) REFERENCES travel_package(id)
);

INSERT INTO travel_package (name, type, price, paragraph1, paragraph2) VALUES
('Baton Matte', 'blz', 1500, 'Manaus, no coracao da Floresta Amazonica, e conhecida pela biodiversidade e importancia historica no ciclo da borracha. Principais atracoes: o Teatro Amazonas e o Encontro das Aguas, onde os rios Negro e Solimoes se encontram sem se misturar.', 'Pacotes turisticos para Manaus incluem visitas guiadas pela floresta, cruzeiros e excursoes para ver fauna local como botos e macacos. Pacotes de 3 a 7 dias custam de R$ 1.500 a R$ 4.500, com transporte, hospedagem e algumas refeicoes.');

INSERT INTO travel_package (name, type, price, paragraph1, paragraph2) VALUES
('Chá de camomila', 'chás', 1000, 'Foz do Iguacu, localizada na fronteira entre Brasil, Argentina e Paraguai, e famosa pelas Cataratas do Iguacu e pela Usina de Itaipu. A cidade tambem abriga o Parque das Aves e o Marco das Tres Fronteiras, onde os rios Iguacu e Parana se encontram.', 'Os pacotes turisticos costumam incluir visitas as cataratas (tanto pelo lado brasileiro quanto pelo argentino), passeios de barco, e ate sobrevoos de helicoptero. Um pacote de 4 dias custa entre R$ 1.500 e R$ 3.000, incluindo hospedagem e transporte.');

INSERT INTO travel_package (name, type, price, paragraph1, paragraph2) VALUES
('Chá de Hibisco', 'chás', 1500, 'A capital baiana e um dos principais centros culturais do Brasil, com o Pelourinho listado como Patrimonio Mundial pela UNESCO. A cidade possui atrações como a Igreja de Sao Francisco, o Elevador Lacerda, que liga a cidade alta à cidade baixa.', 'Os pacotes turisticos variam de R$ 1500 a R$ 3000 para estadias de 5 a 7 dias, com hospedagem, visitas guiadas e acesso as praias. Durante o Carnaval, os pacotes incluem camarotes e ingressos para trios eletricos, com precos mais elevados.');

INSERT INTO travel_package (name, type, price, paragraph1, paragraph2) VALUES
('Chá Verde', 'chás', 1500, 'Gramado, na Serra Gaucha, e famosa pelo clima europeu, arquitetura alpina e eventos como Natal Luz e o Festival de Cinema. Atrações incluem Lago Negro, Mini Mundo, Rua Coberta e o parque Snowland com neve artificial no Brasil.', 'Os pacotes turisticos para Gramado sao populares no inverno e Natal Luz, com precos de R$ 2.000 a R$ 4.000 para pacotes de 4 a 6 dias, incluindo transporte, hospedagem em hoteis charmosos, ingressos para parques e eventos especiais.');

INSERT INTO travel_package (name, type, price, paragraph1, paragraph2) VALUES
('Hortelã organica', 'ervas', 4000, 'Bali e rica em diversidade cultural e paisagens, com praias, montanhas e campos de arroz. As principais cidades sao Ubud, Canggu e Seminyak. Destaques incluem os templos Tanah Lot e Uluwatu, praias de Nusa Dua e Sanur, e o terraço de arroz de Tegalalang.', 'Pacotes turisticos incluem visitas a templos, aulas de surf em Kuta e passeios para as ilhas Gili. Aluguel de moto custa de R$ 114 a R$ 171 por semana. Motorista privado custa cerca de R$ 285. Algumas atracoes cobram taxas de entrada, cerca de 15.000 IDR.');

INSERT INTO travel_package (name, type, price, paragraph1, paragraph2) VALUES
('Manjericão italiano', 'ervas', 3800, 'Toquio e o coracao do Japao, com pontos turisticos como Shibuya, Shinjuku e Akihabara. Atraçoes incluem o Templo Senso-ji, Torre de Toquio, Jardim Imperial e Tokyo Disneyland. Visite Roppongi Hills e os bares de Golden Gai para uma experiencia unica.', 'Pacotes turisticos para Toquio começam em R$ 8.534,10, incluindo passagens, hospedagem e passeios opcionais como barco yakata-bune e ingressos para Tokyo Disneyland. O metrô e o Japan Rail Pass facilitam viagens pela cidade e para Kyoto e Osaka.');

INSERT INTO travel_package (name, type, price, paragraph1, paragraph2) VALUES
('Máscara Capilar Nutritiva', 'blz', 10000, 'Reykjavik e um destino para quem busca aventura e natureza. Atrações incluem a Blue Lagoon, o Circulo Dourado (Thingvellir, Geysir, Gullfoss), a Harpa Concert Hall e a Igreja Hallgrimskirkja, que oferece vistas panoramicas da cidade.', 'Pacotes turisticos incluem passeios para ver a aurora boreal (setembro a abril), cavernas de gelo e trilhas por vulcoes e geleiras');

INSERT INTO travel_package (name, type, price, paragraph1, paragraph2) VALUES
('Salvia desidratada', 'ervas', 6900, 'Santorini e famosa pelas paisagens pitorescas e destino popular para lua de mel. As principais cidades sao Fira, centro economico, e Oia, famosa pelos pores do sol.', 'Os pacotes turisticos para Santorini incluem hospedagem em hoteis de luxo com vista para o mar Egeu e passeios de barco. Os precos variam de R$6.827 a R$14.223 por semana, podendo chegar a mais de R$17.068 para hoteis boutique com spa e jantares privados.');

INSERT INTO travel_package (name, type, price, paragraph1, paragraph2) VALUES
    ('Sérum Facial Hidratante', 'blz', 6900, 'Santorini e famosa pelas paisagens pitorescas e destino popular para lua de mel. As principais cidades sao Fira, centro economico, e Oia, famosa pelos pores do sol.', 'Os pacotes turisticos para Santorini incluem hospedagem em hoteis de luxo com vista para o mar Egeu e passeios de barco. Os precos variam de R$6.827 a R$14.223 por semana, podendo chegar a mais de R$17.068 para hoteis boutique com spa e jantares privados.');

INSERT INTO travel_package (name, type, price, paragraph1, paragraph2) VALUES
    ('Óleo Essencial de Eucalipto', 'ÓleoEss', 6900, 'Santorini e famosa pelas paisagens pitorescas e destino popular para lua de mel. As principais cidades sao Fira, centro economico, e Oia, famosa pelos pores do sol.', 'Os pacotes turisticos para Santorini incluem hospedagem em hoteis de luxo com vista para o mar Egeu e passeios de barco. Os precos variam de R$6.827 a R$14.223 por semana, podendo chegar a mais de R$17.068 para hoteis boutique com spa e jantares privados.');

INSERT INTO travel_package (name, type, price, paragraph1, paragraph2) VALUES
    ('Óleo Essencial de Hortelã-Pimenta', 'ÓleoEss', 6900, 'Santorini e famosa pelas paisagens pitorescas e destino popular para lua de mel. As principais cidades sao Fira, centro economico, e Oia, famosa pelos pores do sol.', 'Os pacotes turisticos para Santorini incluem hospedagem em hoteis de luxo com vista para o mar Egeu e passeios de barco. Os precos variam de R$6.827 a R$14.223 por semana, podendo chegar a mais de R$17.068 para hoteis boutique com spa e jantares privados.');

INSERT INTO travel_package (name, type, price, paragraph1, paragraph2) VALUES
    ('Óleo Essencial de lavanda', 'ÓleoEss', 6900, 'Santorini e famosa pelas paisagens pitorescas e destino popular para lua de mel. As principais cidades sao Fira, centro economico, e Oia, famosa pelos pores do sol.', 'Os pacotes turisticos para Santorini incluem hospedagem em hoteis de luxo com vista para o mar Egeu e passeios de barco. Os precos variam de R$6.827 a R$14.223 por semana, podendo chegar a mais de R$17.068 para hoteis boutique com spa e jantares privados.');

UPDATE travel_package SET
                          paragraph1 = 'O Baton Matte é um item essencial na categoria de Beleza, oferecendo acabamento de alta qualidade, ideal para qualquer ocasião. Disponível em diversas tonalidades, é perfeito para destacar o visual.',
                          paragraph2 = 'Este produto de beleza está disponível em diversas lojas físicas e online, com preços variando de R$ 1.200 a R$ 1.800, dependendo da marca e da edição limitada.'
WHERE name = 'Baton Matte';

UPDATE travel_package SET
                          paragraph1 = 'O Chá de Camomila é amplamente conhecido por suas propriedades calmantes e relaxantes, sendo um dos favoritos entre os apreciadores de Chás. Ideal para ser consumido à noite ou em momentos de descanso.',
                          paragraph2 = 'Disponível em embalagens práticas, o Chá de Camomila pode ser encontrado por valores que variam entre R$ 800 e R$ 1.200, dependendo da origem e do fornecedor.'
WHERE name = 'Chá de camomila';

UPDATE travel_package SET
                          paragraph1 = 'O Chá de Hibisco é conhecido por seus benefícios à saúde, como auxílio na perda de peso e na melhoria da circulação. Uma escolha ideal para quem busca uma rotina mais saudável.',
                          paragraph2 = 'Encontrado em versões naturais ou processadas, o Chá de Hibisco tem preços que variam de R$ 1.200 a R$ 1.800, dependendo da qualidade e do volume adquirido.'
WHERE name = 'Chá de Hibisco';

UPDATE travel_package SET
                          paragraph1 = 'O Chá Verde é um clássico entre os Chás, apreciado por suas propriedades antioxidantes e energéticas, sendo uma escolha popular para momentos de bem-estar.',
                          paragraph2 = 'Com preços entre R$ 1.500 e R$ 2.000, o Chá Verde pode ser encontrado em mercados e lojas especializadas, oferecendo qualidade premium e blends diferenciados.'
WHERE name = 'Chá Verde';

UPDATE travel_package SET
                          paragraph1 = 'A Hortelã Orgânica é uma erva versátil amplamente utilizada em chás, receitas e como aromatizante natural, destacando-se por seu sabor refrescante.',
                          paragraph2 = 'Cultivada de forma sustentável, a Hortelã Orgânica pode ser adquirida a partir de R$ 3.500, com variações dependendo da embalagem e do produtor.'
WHERE name = 'Hortelã organica';

UPDATE travel_package SET
                          paragraph1 = 'O Manjericão Italiano é uma erva aromática indispensável na culinária, especialmente em pratos mediterrâneos e molhos, proporcionando sabor e frescor únicos.',
                          paragraph2 = 'Disponível em mercados e lojas especializadas, o Manjericão Italiano pode ser encontrado por preços que variam de R$ 3.200 a R$ 4.000, dependendo da procedência.'
WHERE name = 'Manjericão italiano';

UPDATE travel_package SET
                          paragraph1 = 'A Máscara Capilar Nutritiva é um produto essencial na categoria de Beleza, desenvolvida para hidratar e revitalizar cabelos secos e danificados, proporcionando brilho e maciez.',
                          paragraph2 = 'Este item premium pode ser adquirido por preços que variam entre R$ 9.000 e R$ 12.000, disponível em lojas especializadas em beleza e cuidados capilares.'
WHERE name = 'Máscara Capilar Nutritiva';

UPDATE travel_package SET
                          paragraph1 = 'A Sálvia Desidratada é uma erva amplamente utilizada na culinária, com propriedades aromáticas intensas que enriquecem pratos diversos e infusões.',
                          paragraph2 = 'Com preços a partir de R$ 6.000, a Sálvia Desidratada está disponível em embalagens práticas, sendo uma escolha popular entre chefs e entusiastas da cozinha.'
WHERE name = 'Salvia desidratada';

UPDATE travel_package SET
                          paragraph1 = 'O Sérum Facial Hidratante é um produto essencial de Beleza, formulado para hidratar profundamente e restaurar a vitalidade da pele, indicado para todos os tipos de pele.',
                          paragraph2 = 'Disponível em embalagens de 30ml ou mais, o Sérum Facial Hidratante pode ser encontrado com preços entre R$ 6.000 e R$ 8.000, dependendo da marca e da fórmula.'
WHERE name = 'Sérum Facial Hidratante';

UPDATE travel_package SET
                          paragraph1 = 'O Óleo Essencial de Eucalipto é conhecido por suas propriedades terapêuticas, sendo amplamente utilizado em aromaterapia e cuidados respiratórios.',
                          paragraph2 = 'Com preços variando de R$ 6.500 a R$ 7.500, este óleo essencial pode ser adquirido em lojas especializadas e mercados de produtos naturais.'
WHERE name = 'Óleo Essencial de Eucalipto';

UPDATE travel_package SET
                          paragraph1 = 'O Óleo Essencial de Hortelã é valorizado por sua fragrância refrescante e propriedades revigorantes, sendo um dos favoritos na categoria de Óleos Essenciais.',
                          paragraph2 = 'Com valores entre R$ 6.500 e R$ 7.500, este óleo é amplamente encontrado em lojas especializadas e distribuidores de produtos naturais.'
WHERE name = 'Óleo Essencial de Hortelã';

UPDATE travel_package SET
                          paragraph1 = 'O Óleo Essencial de Lavanda é um dos mais populares Óleos Essenciais, conhecido por suas propriedades calmantes e relaxantes, ideal para momentos de bem-estar.',
                          paragraph2 = 'Disponível em frascos de 10ml ou mais, este óleo tem preços que variam entre R$ 6.500 e R$ 7.500, dependendo da pureza e da marca.'
WHERE name = 'Óleo Essencial de lavanda';
